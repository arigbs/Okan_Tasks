All of these images are taken from 100% royalty free sites, 
and have afterwards been edited. 

Although you might want to add your own calendar button image.

Have fun!